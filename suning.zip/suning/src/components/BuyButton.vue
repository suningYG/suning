<template>
    <h1>
        {{num}}人团
    </h1>
</template>
<script>
export default {
    data() {
        return {
            num:2
        }
    },
}
</script>
<style lang="stylus" scoped>

</style>