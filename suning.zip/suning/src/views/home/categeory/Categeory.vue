<template>
    <div>
        <router-link to="/shopList">商品列表</router-link>
        <router-link to="/search">搜索</router-link>
        <router-link to="/typeScreen">筛选</router-link>
        <router-view></router-view>
        categeory
    </div>
</template>

<script>
export default {
    
}
</script>
<style lang="stylus" scoped>

</style>